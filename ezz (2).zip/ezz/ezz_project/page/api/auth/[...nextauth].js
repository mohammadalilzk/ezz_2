// /pages/api/auth/[...nextauth].js
import NextAuth from "next-auth";
import TwitterProvider from "next-auth/providers/twitter";
import { supabase } from "../../../lib/supabase";

export default NextAuth({
  providers: [
    TwitterProvider({
      clientId: process.env.TWITTER_CLIENT_ID,
      clientSecret: process.env.TWITTER_CLIENT_SECRET,
    }),
  ],
  secret: process.env.NEXTAUTH_SECRET,
  callbacks: {
    async jwt({ token, account, user }) {
      if (account) {
        token.accessToken = account.access_token;

        // Store or update the access token in the accounts table
        const { data, error } = await supabase
          .from('accounts')
          .upsert({
            userid: user?.id,
            provider: account.provider,
            provideraccountid: account.providerAccountId,
            accesstoken: account.access_token,
            accesstokenexpires: new Date(account.expires_at! * 1000).toISOString(),
            refreshtoken: account.refresh_token,
          }, {
            onConflict: 'provideraccountid',
          });

        if (error) {
          console.error('Error storing Twitter access token in Supabase:', error);
        }
      }
      return token;
    },
    async session({ session, token }) {
      session.accessToken = token.accessToken as string | undefined;
      return session;
    },
  },
});
