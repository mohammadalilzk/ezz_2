// /pages/api/twitter-post.js
export default async function handler(req, res) {
  if (req.method === 'POST') {
    const { content } = req.body;
    const accessToken = req.headers.authorization.split(' ')[1];

    const response = await fetch('https://api.twitter.com/2/tweets', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        text: content,
      }),
    });

    if (response.ok) {
      res.status(200).json({ message: 'Tweet posted successfully' });
    } else {
      res.status(500).json({ message: 'Failed to post tweet' });
    }
  } else {
    res.status(405).json({ message: 'Method not allowed' });
  }
}
