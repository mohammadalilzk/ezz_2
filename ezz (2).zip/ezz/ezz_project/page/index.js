// /pages/index.js
import TwitterPost from '../components/TwitterPost';
import SignOutButton from '../components/SignOutButton';
import { signIn } from 'next-auth/react';

export default function Home() {
  return (
    <div>
      <h1>Welcome to Twitter Poster</h1>
      <button onClick={() => signIn('twitter')}>Sign in with Twitter</button>
      <TwitterPost />
      <SignOutButton />
    </div>
  );
}
