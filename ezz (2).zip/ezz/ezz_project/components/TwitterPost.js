// /components/TwitterPost.js
import { useSession } from 'next-auth/react';
import { useState } from 'react';

export default function TwitterPost() {
  const { data: session } = useSession();
  const [tweetContent, setTweetContent] = useState('');

  const shareTweet = async () => {
    const response = await fetch('/api/twitter-post', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${session.accessToken}`,
      },
      body: JSON.stringify({ content: tweetContent }),
    });

    if (response.ok) {
      alert('Tweet posted successfully!');
    } else {
      alert('Failed to post tweet');
    }
  };

  return (
    <div>
      <textarea 
        value={tweetContent} 
        onChange={(e) => setTweetContent(e.target.value)} 
        placeholder="Write your tweet here" 
      />
      <button onClick={shareTweet}>Share on Twitter</button>
    </div>
  );
}
